npm warn exec The following package was not found and will be installed: supabase@2.34.3
npm warn deprecated node-domexception@1.0.0: Use your platform's native DOMException instead
2025/08/21 21:38:32 Access token not provided. Supply an access token by running supabase login or setting the SUPABASE_ACCESS_TOKEN environment variable.
